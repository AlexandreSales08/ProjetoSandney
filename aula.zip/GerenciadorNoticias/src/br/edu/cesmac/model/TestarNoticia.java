package br.edu.cesmac.model;

public class TestarNoticia {

	public static void main(String[] args) {
		Noticia not = new Noticia();
		NoticiaWeb noticia = new NoticiaWeb();
		
		noticia.setVideo("alvaro.mpeg");
		noticia.setTextoNoticia("Um texto da not�cia");

		System.out.println(noticia.getVideo());
		System.out.println(noticia.getTextoNoticia());
	}
	
}
