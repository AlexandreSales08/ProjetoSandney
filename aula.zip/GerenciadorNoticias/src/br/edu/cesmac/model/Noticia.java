package br.edu.cesmac.model;

import java.util.Date;

public abstract class Noticia {
	protected int idNoticia;
	protected String tituloNoticia;
	protected String resumoNoticia;
	protected Date dataNoticia;
	protected String textoNoticia;
	protected Jornalista jornalista;
	protected Editoria editoria;

	public abstract String exibirNoticia();
	
	public int getIdNoticia() {
		return idNoticia;
	}

	public void setIdNoticia(int idNoticia) {
		this.idNoticia = idNoticia;
	}

	public String getTituloNoticia() {
		return tituloNoticia;
	}

	public void setTituloNoticia(String tituloNoticia) {
		this.tituloNoticia = tituloNoticia;
	}

	public String getResumoNoticia() {
		return resumoNoticia;
	}

	public void setResumoNoticia(String resumoNoticia) {
		this.resumoNoticia = resumoNoticia;
	}

	public Date getDataNoticia() {
		return dataNoticia;
	}

	public void setDataNoticia(Date dataNoticia) {
		this.dataNoticia = dataNoticia;
	}

	public String getTextoNoticia() {
		return textoNoticia;
	}

	public void setTextoNoticia(String textoNoticia) {
		this.textoNoticia = textoNoticia;
	}

	public Jornalista getJornalista() {
		return jornalista;
	}

	public void setJornalista(Jornalista jornalista) {
		this.jornalista = jornalista;
	}

	public Editoria getEditoria() {
		return editoria;
	}

	public void setEditoria(Editoria editoria) {
		this.editoria = editoria;
	}
}
