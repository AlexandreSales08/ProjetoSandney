package br.edu.cesmac.model;

public class NoticiaWeb extends Noticia {

	private String video;
	private String imagem;

	public String getVideo() {
		return video;
	}

	public void setVideo(String video) {
		this.video = video;
	}

	public String getImagem() {
		return imagem;
	}

	public void setImagem(String imagem) {
		this.imagem = imagem;
	}

	
	public String exibirNoticia() {
		// TODO Auto-generated method stub
		return null;
	}

}
