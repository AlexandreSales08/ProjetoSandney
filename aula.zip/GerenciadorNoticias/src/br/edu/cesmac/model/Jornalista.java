package br.edu.cesmac.model;

public class Jornalista {
	private int idJornalista;
	private String nomeJornalista;

	public int getIdJornalista() {
		return idJornalista;
	}

	public void setIdJornalista(int idJornalista) {
		this.idJornalista = idJornalista;
	}

	public String getNomeJornalista() {
		return nomeJornalista;
	}

	public void setNomeJornalista(String nomeJornalista) {
		this.nomeJornalista = nomeJornalista;
	}

}
