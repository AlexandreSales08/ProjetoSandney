package br.edu.cesmac.JDBC;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class InsereJdbc {
	public static void main(String[] args) {
		try (Connection con = new ConnectionFactory().getConnection()) {

			String sql = "INSERT INTO editoria" + " (nome)" + " values (?)";

			PreparedStatement stmt;
			stmt = con.prepareStatement(sql);
			stmt.setString(1, "Editoria B");
			stmt.execute();
			System.out.println("Gravado!");
		} catch (SQLException e) {
			System.out.println(e);
		}

	}

}
